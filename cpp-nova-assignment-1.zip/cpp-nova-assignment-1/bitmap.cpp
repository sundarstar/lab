#include<iostream>
#include<cmath>
#include"bitmap.h"
using namespace std;

Complex::Complex()
{
	real = 0;
    img = 0;
}
	
Complex::Complex(int r, int i)
{
	real = r;
	img = i;
}
	
void Complex::Accept()
{
	cout << "Enter real part: ";
	cin >> real;
	cout << "Enter imaginary part: ";
	cin >> img;
}

void Complex::Display()
{
	cout << real << " + " << img << "i" << endl;
}
	
Complex Complex::operator+(Complex &c)
{
	Complex temp;
	temp.real=real+c.real;
	temp.img=img+c.img;
	return temp;
}
	
Complex Complex::operator-(Complex &c)
{
	Complex temp;
	temp.real=real-c.real;
	temp.img=img-c.img;
	return temp;

}
Complex Complex::operator++()
{
	++real;
	++img;
	return *this;
}
	
Complex Complex::operator++(int)
{
	Complex temp=*this;
	real++;
    img++;
	return temp;
}

bool Complex::operator==(Complex &c)
{
	bool flag=(real == c.real) && (img == c.img);
	return flag;
}
	
	
	
	
	
	
